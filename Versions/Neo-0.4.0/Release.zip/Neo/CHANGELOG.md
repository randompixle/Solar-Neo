## v0.4.0 — Project: Eclipse — November 2, 2025
- New: `neo sys-check` (neofetch-style summary)
- New: `neo uninstall-self`
- New: Self-update from GitHub releases
- Cleaner output (apt+pip hybrid)
