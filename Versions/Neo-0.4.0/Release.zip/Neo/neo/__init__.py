
__version__ = "0.4.0"
__codename__ = "Project: Eclipse"
__author__ = "Alen"
